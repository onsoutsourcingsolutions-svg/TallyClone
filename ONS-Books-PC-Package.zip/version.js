// One place that marks which build of the app is running.
// Both the server banner and the web screens show this, so you can verify
// that an update has really landed (Settings -> bottom of the page).
export const BUILD_TAG = 'v1.11.52 · 15 Sep 2026 — CGST SGST TAXABLE CALC VERIFIED + GST% EDITABLE + 0.068*200000=13600';
