import { useEffect, useState } from 'react';
import { useApp } from '../state.jsx';
import { inr } from '../fmt.js';
import { checkUpdate, applyUpdate } from '../upd.js';

// Home = two live panels: bank balance (from the books) and USD->INR rate.
export function Gateway() {
  const { company, notify } = useApp();
  const [banks, setBanks] = useState(null); // rows when loaded
  const [fx, setFx] = useState(null);       // { rate, updatedAt, source } | null = unavailable
  const [fxState, setFxState] = useState('load'); // load | ok | off | busy
  const [usdIn, setUsdIn] = useState('');
  const [upd, setUpd] = useState(null);     // update-check result (null = not fetched yet)
  const [updBusy, setUpdBusy] = useState(false);

  const loadBanks = async () => {
    try {
      const j = await fetch('/api/accounts?with_balances=1').then((r) => r.json());
      const rows = (j.rows || []).filter((a) => a.kind === 'Bank' && a.active !== 0);
      setBanks(rows);
    } catch (e) { notify(e.message); }
  };

  const loadFx = async (silent = false) => {
    if (!silent) setFxState('busy');
    try {
      const j = await fetch('/api/rates').then((r) => r.json());
      if (j && j.ok && j.usd) { setFx(j.usd); setFxState('ok'); }
      else { setFx(null); setFxState('off'); }
    } catch (e) { setFx(null); setFxState('off'); }
  };

  useEffect(() => { loadBanks(); loadFx(true); checkUpdate().then((j) => setUpd(j)); }, []);

  const doUpdate = async () => {
    setUpdBusy(true);
    try { await applyUpdate(); }
    catch (e) { notify(e.message); setUpdBusy(false); }
  };

  const total = (banks || []).reduce((s, b) => s + (Number(b.balance) || 0), 0);
  const rate = fx ? fx.rate : 0;
  const converted = rate > 0 && usdIn !== '' && Number(usdIn) > 0 ? Math.round(Number(usdIn) * rate * 100) : 0;

  const timeHM = (iso) => {
    try { return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch (_) { return ''; }
  };

  return (
    <div style={{ maxWidth: 980, margin: '0 auto' }}>
      {upd && upd.update && upd.latest && (
        <div style={{
          display: 'flex', gap: 10, alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap',
          border: '1px solid var(--gold-line)', borderRadius: 8, background: 'linear-gradient(180deg, rgba(212,175,55,0.10), rgba(212,175,55,0.02))',
          padding: '9px 12px', marginBottom: 14,
        }}>
          <span style={{ fontSize: 13.5 }}>
            <b style={{ color: 'var(--gold-hi)' }}>New build {upd.latest.replace(/ ·.*/, '')} is ready</b>
            <span className="muted"> — install it here in one click; your books are never touched.</span>
          </span>
          <button className="btn" style={{ padding: '6px 14px' }} disabled={updBusy} onClick={doUpdate}>
            {updBusy ? 'Installing… app restarts' : 'Update now'}
          </button>
        </div>
      )}
      {company && company.financial_year_from && (
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 10 }}>
          <span className="badge gold">FY {company.financial_year_from.slice(0, 4)}–{Number(company.financial_year_from.slice(0, 4)) + 1}</span>
        </div>
      )}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, alignItems: 'flex-start' }}>

        {/* ---------- column 1: bank balance ---------- */}
        <div className="card" style={{ marginBottom: 0, flex: '1 1 320px', maxWidth: '100%' }}>
          <h3>Bank balance · from your books</h3>
          <div style={{ fontFamily: 'var(--serif)', fontSize: 38, color: 'var(--gold-hi)', lineHeight: 1.1, margin: '4px 0 10px' }}>
            {banks === null ? <span className="faint" style={{ fontSize: 18, fontFamily: 'var(--sans)' }}>Loading…</span>
              : <>{total < 0 ? '−' : ''}{inr(Math.abs(total))}</>}
          </div>
          {banks !== null && banks.length === 0 && (
            <p className="muted" style={{ fontSize: 13.5 }}>
              No bank ledgers yet — add them under <b>Ledgers</b> (group “Bank Accounts”) and enter a receipt/contra to see the balance here.
            </p>
          )}
          {banks !== null && banks.length > 0 && (
            <table className="grid" style={{ fontSize: 13 }}>
              <thead><tr><th>Account</th><th className="tright">Balance</th></tr></thead>
              <tbody>
                {banks.map((b) => (
                  <tr key={b.id}>
                    <td>{b.name}</td>
                    <td className="tright num">
                      {Number(b.balance) === 0 ? <span className="faint">—</span>
                        : <>{Number(b.balance) < 0 ? '−' : ''}{inr(Math.abs(Number(b.balance)))} {Number(b.balance) < 0 && <span className="tag">Cr</span>}</>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="faint" style={{ fontSize: 11.5, margin: '10px 0 0' }}>
            Live total of every ledger in Bank Accounts. Tap a bank’s row on the ledger report for full statements.
          </p>
        </div>

        {/* ---------- column 2: dollar rate ---------- */}
        <div className="card" style={{ marginBottom: 0, flex: '1 1 320px', maxWidth: '100%' }}>
          <h3>Dollar rate · USD → INR</h3>
          {fxState === 'load' || fxState === 'busy' ? (
            <div style={{ fontFamily: 'var(--serif)', fontSize: 38, color: 'var(--gold-hi)', margin: '4px 0 10px' }}>
              <span className="faint" style={{ fontSize: 18, fontFamily: 'var(--sans)' }}>{fxState === 'load' ? 'Fetching…' : 'Refreshing…'}</span>
            </div>
          ) : fxState === 'ok' && fx ? (
            <>
              <div style={{ fontFamily: 'var(--serif)', fontSize: 38, color: 'var(--gold-hi)', margin: '4px 0 10px' }}>
                ₹ {rate.toFixed(2)}
                <span style={{ fontSize: 14, fontFamily: 'var(--sans)', color: 'var(--ink-dim)' }}> / 1 USD</span>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: 12 }}>
                <input style={{ maxWidth: 160 }} placeholder="USD amount" inputMode="decimal" value={usdIn}
                  onChange={(e) => setUsdIn(e.target.value.replace(/[^0-9.]/g, ''))} />
                <b className="num" style={{ color: 'var(--gold-hi)' }}>{converted ? inr(converted) : ''}</b>
              </div>
            </>
          ) : (
            <div style={{ fontFamily: 'var(--serif)', fontSize: 26, color: 'var(--gold-dim)', margin: '4px 0 10px' }}>Rate unavailable</div>
          )}
          <p className="muted" style={{ fontSize: 12.5, margin: '0 0 8px' }}>
            {fx ? <>Updated {timeHM(fx.updatedAt)} · {fx.source} · internet needed for live rate</> : 'Could not reach the rate service — this PC needs internet for the live rate.'}
          </p>
          <button className="btn ghost" disabled={fxState === 'busy'} onClick={() => loadFx()}>
            {fxState === 'busy' ? 'Fetching…' : '⟳ Refresh rate'}
          </button>
        </div>
      </div>

      <p className="faint" style={{ fontSize: 12, textAlign: 'center', marginTop: 18 }}>
        All screens are in the ☰ menu (Ledgers, Vouchers, Reports, Import/Export…)
      </p>
    </div>
  );
}
